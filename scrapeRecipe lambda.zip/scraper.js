import * as cheerio from 'cheerio';
import cloudscraper from 'cloudscraper';

//const URL = "https://www.allrecipes.com/recipe/279991/lemony-almond-ricotta-cookies/";

const numberWords = [
    "One", "Two", "Three", "Four",
    "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen",
    "Fourteen", "Fifteen", "Sixteen",
    "Seventeen", "Eighteen", "Nineteen",
    "Twenty"
];

export const handler = async (event) => {
try{
    const body = JSON.parse(event.body || {});
    const url = body.url;

    if (!url) {
        throw new Error("No URL provided");
    }

    const recipe = await scrape(url);

    return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json",
          "Access-Control-Allow-Origin": "*"
        },
        body: JSON.stringify(recipe)
      };
} catch(err){
    return {
         statusCode: 500,
         body: JSON.stringify({ error: err.message }) }
}}


async function scrape(url) {

    const html = await cloudscraper.get(url);

    const $ = cheerio.load(html);

    // NAME
    const name = $("h1.article-heading.text-headline-400")
        .text()
        .trim();

    // INGREDIENTS
    const ingredients = [];

    $("ul.mm-recipes-structured-ingredients__list li")
        .each((i, el) => {

            ingredients.push(
                $(el)
                    .text()
                    .trim()
                    .replace(/\s+/g, " ")
            );
        });

    // INSTRUCTIONS
    const instructions = {};

    $("ol.comp.mntl-sc-block.mntl-sc-block-startgroup.mntl-sc-block-group--OL li")
        .each((i, el) => {

            const stepName = `Step ${numberWords[i + 1] || (i + 1)}`;

            instructions[stepName] = $(el)
                .text()
                .trim()
                .replace(/\s+/g, " ");
        });

    return {
        url,
        name,
        ingredients,
        instructions
    };
}