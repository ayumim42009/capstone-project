import * as cheerio from 'cheerio';
//import chromium from "@sparticuz/chromium";
//import { chromium as pwChromium } from "playwright";
import cloudscraper from 'cloudscraper';


//const URL = "https://www.allrecipes.com/recipe/279991/lemony-almond-ricotta-cookies/";

const numberWords = [
    "One", "Two", "Three", "Four",
    "Five", "Six", "Seven", "Eight", "Nine",
    "Ten", "Eleven", "Twelve", "Thirteen",
    "Fourteen", "Fifteen", "Sixteen",
    "Seventeen", "Eighteen", "Nineteen",
    "Twenty"
];

/*export const handler = async (event) => {
    return {
        statusCode: 200,
        body: JSON.stringify({ ok: true })
    };
};*/

export const handler = async (event) => {

try{
    //const body = JSON.parse(event.body);
    let body = {};

        if (event.body) {
            body = typeof event.body === "string"
                ? JSON.parse(event.body)
                : event.body;
        }
    
    const url = body.url;

    if (!url) {
        throw new Error("No URL provided");
    }

    const recipe = await scrape(url);

    return {
        statusCode: 200,
        headers: {
          "Content-Type": "application/json"
        },
        body: JSON.stringify(recipe)
      };
} catch(err){
    //console.log("BLOCK DETECTED:", html.includes("Simple Page"));
    console.error("LAMBDA ERROR:", err);
    return {
        statusCode: 500,
        body: JSON.stringify({
            error: err.message,
            stack: err.stack
        })
    }}


async function scrape(url) {

    console.log("START SCRAPE:", url);

    /*const browser = await pwChromium.launch({
        args: chromium.args,
        executablePath: await chromium.executablePath(),
        headless: chromium.headless
    });*/
    //try
    //{
        //const page = await browser.newPage();
        //await page.goto(url, { waitUntil: "domcontentloaded"})
        //const html = await page.content();
        const html = await cloudscraper.get(url);
        
        /*const result = await fetch(url, {
            headers: {
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/101.0.4951.54 Safari/537.36",
                "Accept": "text/html",
            }
        })*/

        const jsonLd = $('script[type="application/ld+json"]').html();
        console.log(jsonLd);
        //const html = await result.text();
        const $ = cheerio.load(html);
        //console.log($.html().slice(0, 1000));
        // NAME
        const name = $("h1.article-heading.text-headline-400")
            .text()
            .trim();

        // INGREDIENTS
        const ingredients = [];

        $("ul.mm-recipes-structured-ingredients__list li")
            .each((i, el) => {

                ingredients.push(
                    $(el)
                        .text()
                        .trim()
                        .replace(/\s+/g, " ")
                );
            });

        // INSTRUCTIONS
        const instructions = {};

        $("ol.comp.mntl-sc-block.mntl-sc-block-startgroup.mntl-sc-block-group--OL li")
            .each((i, el) => {

                const stepName = `Step ${numberWords[i + 1] || (i + 1)}`;

                instructions[stepName] = $(el)
                    .text()
                    .trim()
                    .replace(/\s+/g, " ");
            });
        return {
            url,
            name,
            ingredients,
            instructions
        };
    /*}
    finally{
        await browser.close();
    }*/
}}